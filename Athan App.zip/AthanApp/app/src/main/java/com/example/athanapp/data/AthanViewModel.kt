package com.example.athanapp.data

import androidx.lifecycle.ViewModel

class AthanViewModel : ViewModel() {

}