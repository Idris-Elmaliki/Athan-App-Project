package com.example.athanapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.athanapp.ui.MainMenuLayout
import com.example.athanapp.ui.theme.AthanAppTheme
import com.example.athanapp.ui.SettingsLayOut

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AthanAppTheme {
                Surface {
                    AppLayout(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .statusBarsPadding()
                    )
                }
            }
        }
    }
}

enum class AthanAppScreen() {
    Main,
    Settings
}

@Composable
fun AppLayout(
    modifier: Modifier = Modifier,
    navController : NavHostController = rememberNavController()
) {
    Scaffold(
        modifier = modifier
    ) { innerpadding ->
        NavHost(
            navController = navController,
            startDestination = AthanAppScreen.Main.name,
            modifier = Modifier
                .padding(innerpadding)
        ) {
            composable(route = AthanAppScreen.Main.name) {
                MainMenuLayout(
                    navigateToSettings = {
                        navController.navigate(AthanAppScreen.Settings.name)
                    }
                )
            }
            composable(route = AthanAppScreen.Settings.name) {
                SettingsLayOut(
                    navigateToAthanScreen = {
                        returnToAthanScreen(navController)
                    }
                )
            }
        }
    }
}

private fun returnToAthanScreen(
    navController : NavHostController
) {
    navController.popBackStack(AthanAppScreen.Main.name, false)
}


@Preview(
    showBackground = true,
    showSystemUi = true,
    name = "Testing"
)
@Composable
fun GreetingPreview() {
    AthanAppTheme {
        AppLayout()
    }
}